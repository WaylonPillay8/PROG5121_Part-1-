public class BubbleSortTask {

    /*
     * This method sorts the array in ASCENDING order (smallest to biggest).
     * This is the main method that follows the pseudocode I was given.
     * It also counts how many swaps happen (this is one of the bonus tasks).
     */
    public static int bubbleSort(int[] array) {
        int n = array.length;   // n = how many numbers are in the array
        int swapCount = 0;      // this keeps track of how many swaps we do

        // The outer loop runs once for every number in the array.
        // Each time it runs, the next biggest number gets moved into place.
        for (int i = 0; i < n - 1; i++) {

            // The inner loop compares each pair of numbers next to each
            // other. We use "n - i - 1" because after each pass, the last
            // few numbers are already sorted, so we don't need to check them
            // again.
            for (int j = 0; j < n - i - 1; j++) {

                // If the number on the left is bigger than the number on
                // the right, they are in the wrong order, so we swap them.
                if (array[j] > array[j + 1]) {

                    // To swap two numbers we need a temporary variable to
                    // hold one of the values while we move things around.
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;

                    swapCount++; // we did a swap, so add 1 to our counter
                }
            }
        }

        return swapCount; // give back the total number of swaps
    }

    /*
     * BONUS TASK: sort the array in DESCENDING order (biggest to smallest).
     * This is almost exactly the same as bubbleSort above, except I changed
     * the "if" condition from > to <, like the hint suggested.
     */
    public static int bubbleSortDescending(int[] array) {
        int n = array.length;
        int swapCount = 0;

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {

                // Now we swap when the left number is SMALLER, so the
                // bigger numbers move to the front instead of the back.
                if (array[j] < array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;

                    swapCount++;
                }
            }
        }

        return swapCount;
    }

    /*
     * This method just prints out the array so we can see what it looks
     * like before and after sorting. The "message" parameter lets us
     * label the output, e.g. "Before sorting" or "After sorting".
     */
    public static void printArray(String message, int[] array) {
        System.out.print(message + ": ");

        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]);

            // Only print a comma if this is not the last number
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }

        System.out.println(); // move to a new line after printing the array
    }

    public static void main(String[] args) {

        // Sample array to test my bubbleSort method
        int[] numbers = {5, 2, 9, 1, 6};

        System.out.println("--- Ascending Sort ---");
        printArray("Before sorting", numbers);

        int swaps = bubbleSort(numbers);

        printArray("After sorting", numbers);
        System.out.println("Number of swaps: " + swaps);

        System.out.println();

        // Bonus: testing the descending sort with a fresh copy of the array
        int[] numbers2 = {5, 2, 9, 1, 6};

        System.out.println("--- Descending Sort (Bonus) ---");
        printArray("Before sorting", numbers2);

        int swaps2 = bubbleSortDescending(numbers2);

        printArray("After sorting", numbers2);
        System.out.println("Number of swaps: " + swaps2);
    }
}