import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.nio.file.Files;

public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;

    // -----------------------------------------------------------------------
    // Part 3 arrays
    // -----------------------------------------------------------------------
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static ArrayList<Message> storedMessages = new ArrayList<>();
    private static ArrayList<String> messageHashes = new ArrayList<>();
    private static ArrayList<String> messageIDs = new ArrayList<>();

    private static int totalMessageCount = 0;

    // The phone number of the person using QuickChat (the "sender")
    private static String senderNumber = "";

    // File used to persist stored messages between sessions
    private static final String STORAGE_FILE = "stored_messages.json";

    // Constructor
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();

        messageIDs.add(this.messageID);
        messageHashes.add(this.messageHash);
    }

    // -----------------------------------------------------------------------
    // Private constructor used when re-creating Message objects from the
    // stored_messages.json file (fields are already known, so they are not
    // regenerated).
    // -----------------------------------------------------------------------
    private Message(String messageID, int messageNumber, String recipient,
                     String messageText, String messageHash) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = messageHash;
    }

    // Generates a random 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        long id = (long) (rand.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    // -----------------------------------------------------------------------
    // Boolean: checkMessageID()
    // Ensures the message ID is not more than 10 characters
    // -----------------------------------------------------------------------
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // -----------------------------------------------------------------------
    // String: checkRecipientCell()
    // Ensures the recipient cell number is no more than 10 characters long
    // and starts with an international code (i.e. starts with '+')
    // -----------------------------------------------------------------------
    public String checkRecipientCell() {
        if (recipient.length() <= 10 && recipient.startsWith("+")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // -----------------------------------------------------------------------
    // String: checkMessage()
    // Validates message length (max 250 characters)
    // -----------------------------------------------------------------------
    public String checkMessage() {
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }

    // -----------------------------------------------------------------------
    // String: createMessageHash()
    // Format: first 2 digits of messageID + ":" + messageNumber + ":" +
    //         first word of message + last word of message — all in CAPS
    // Example: 00:0:HITONIGHT
    // -----------------------------------------------------------------------
    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);

        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        // Strip trailing punctuation from last word
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");

        String hash = firstTwo + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    // -----------------------------------------------------------------------
    // String: SentMessage()
    // Routes the message to the correct array depending on the user's
    // choice: 1 = send, 2 = disregard, 3 = store.
    // -----------------------------------------------------------------------
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                sentMessages.add(this);
                totalMessageCount++;
                return "Message successfully sent.";
            case 2:
                disregardedMessages.add(this);
                return "Press 0 to delete the message.";
            case 3:
                storedMessages.add(this);
                saveStoredMessagesToFile();
                return "Message successfully stored.";
            default:
                return "Invalid option selected.";
        }
    }

    // -----------------------------------------------------------------------
    // String: printMessages()
    // Returns all messages sent while the program is running
    // -----------------------------------------------------------------------
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n");
            sb.append("-----------------------------\n");
        }
        return sb.toString();
    }

    // -----------------------------------------------------------------------
    // Int: returnTotalMessages()
    // Returns the total number of messages sent
    // -----------------------------------------------------------------------
    public static int returnTotalMessages() {
        return totalMessageCount;
    }

    // =========================================================================
    // PART 3 — Stored messages (JSON persistence)
    // =========================================================================

    // -----------------------------------------------------------------------
    // storeMessage() — kept for backwards compatibility with Part 2.
    // Adds this message to the storedMessages array (if not already there)
    // and writes the whole array out to stored_messages.json.
    // -----------------------------------------------------------------------
    public void storeMessage() {
        if (!storedMessages.contains(this)) {
            storedMessages.add(this);
        }
        saveStoredMessagesToFile();
    }

    // -----------------------------------------------------------------------
    // saveStoredMessagesToFile()
    // Writes the storedMessages array out to stored_messages.json as a JSON
    // array of message objects.
    // -----------------------------------------------------------------------
    private static void saveStoredMessagesToFile() {
        try (FileWriter fw = new FileWriter(STORAGE_FILE)) {
            fw.write("[\n");
            for (int i = 0; i < storedMessages.size(); i++) {
                Message m = storedMessages.get(i);
                fw.write("  {\n");
                fw.write("    \"messageID\": \"" + escapeJson(m.messageID) + "\",\n");
                fw.write("    \"messageNumber\": " + m.messageNumber + ",\n");
                fw.write("    \"recipient\": \"" + escapeJson(m.recipient) + "\",\n");
                fw.write("    \"message\": \"" + escapeJson(m.messageText) + "\",\n");
                fw.write("    \"messageHash\": \"" + escapeJson(m.messageHash) + "\"\n");
                fw.write("  }");
                fw.write(i < storedMessages.size() - 1 ? ",\n" : "\n");
            }
            fw.write("]\n");
        } catch (IOException e) {
            System.out.println("Error storing message: " + e.getMessage());
        }
    }

    // -----------------------------------------------------------------------
    // loadStoredMessagesFromFile()
    // Reads stored_messages.json (if it exists) and populates the
    // storedMessages array, plus the messageIDs / messageHashes arrays.
    //
    // Approach (based on common online examples for lightweight JSON
    // parsing without an external library): split the file's contents into
    // individual { ... } objects with a regular expression, then pull each
    // "key": "value" pair out of the object with its own regular expression.
    // -----------------------------------------------------------------------
    public static void loadStoredMessagesFromFile() {
        storedMessages.clear();

        File file = new File(STORAGE_FILE);
        if (!file.exists()) {
            return;
        }

        try {
            String content = new String(Files.readAllBytes(file.toPath()));

            // Each stored message is a flat JSON object: { ... }
            Matcher objectMatcher = Pattern.compile("\\{[^{}]*\\}").matcher(content);

            while (objectMatcher.find()) {
                String obj = objectMatcher.group();

                String id = extractField(obj, "messageID");
                String numStr = extractField(obj, "messageNumber");
                String recipient = extractField(obj, "recipient");
                String text = extractField(obj, "message");
                String hash = extractField(obj, "messageHash");

                int num = numStr.isEmpty() ? 0 : Integer.parseInt(numStr);

                Message m = new Message(id, num, recipient, text, hash);
                storedMessages.add(m);

                if (!messageIDs.contains(id)) {
                    messageIDs.add(id);
                }
                if (!messageHashes.contains(hash)) {
                    messageHashes.add(hash);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading stored messages: " + e.getMessage());
        }
    }

    // -----------------------------------------------------------------------
    // extractField() — small helper used to pull a single value out of a
    // flat JSON object using a regular expression.
    // -----------------------------------------------------------------------
    private static String extractField(String jsonObject, String key) {
        Pattern pattern;
        if (key.equals("messageNumber")) {
            pattern = Pattern.compile("\"" + key + "\"\\s*:\\s*(\\d+)");
        } else {
            pattern = Pattern.compile("\"" + key + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
        }

        Matcher matcher = pattern.matcher(jsonObject);
        if (matcher.find()) {
            return matcher.group(1).replace("\\\"", "\"").replace("\\\\", "\\");
        }
        return "";
    }

    // -----------------------------------------------------------------------
    // escapeJson() — escapes backslashes and double quotes so message text
    // can be safely written inside a JSON string.
    // -----------------------------------------------------------------------
    private static String escapeJson(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    // =========================================================================
    // PART 3 — Stored Messages menu functionality
    // =========================================================================

    // -----------------------------------------------------------------------
    // 2a. Display the sender and recipient of all stored messages
    // -----------------------------------------------------------------------
    public static String displayStoredSendersAndRecipients() {
        if (storedMessages.isEmpty()) {
            return "No stored messages.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            sb.append("Sender: ").append(senderNumber.isEmpty() ? "Unknown" : senderNumber)
              .append(" | Recipient: ").append(m.recipient).append("\n");
        }
        return sb.toString().trim();
    }

    // -----------------------------------------------------------------------
    // 2b. Display the longest stored message
    // -----------------------------------------------------------------------
    public static String displayLongestStoredMessage() {
        if (storedMessages.isEmpty()) {
            return "No stored messages.";
        }
        Message longest = storedMessages.get(0);
        for (Message m : storedMessages) {
            if (m.messageText.length() > longest.messageText.length()) {
                longest = m;
            }
        }
        return longest.messageText;
    }

    // -----------------------------------------------------------------------
    // 2c. Search for a message ID and display the corresponding recipient
    //     and message. Searches across sent, disregarded and stored messages.
    // -----------------------------------------------------------------------
    public static String searchByMessageID(String id) {
        for (Message m : getAllMessages()) {
            if (m.messageID.equals(id)) {
                return "Recipient: " + m.recipient + " | Message: " + m.messageText;
            }
        }
        return "No message found with ID " + id;
    }

    // -----------------------------------------------------------------------
    // Returns just the message text for a given message ID (used by tests
    // that only check the message content for the matching ID).
    // -----------------------------------------------------------------------
    public static String searchMessageTextByID(String id) {
        for (Message m : getAllMessages()) {
            if (m.messageID.equals(id)) {
                return m.messageText;
            }
        }
        return "No message found with ID " + id;
    }

    // -----------------------------------------------------------------------
    // 2d. Search for all the messages sent or stored for a particular
    //     recipient.
    // -----------------------------------------------------------------------
    public static String searchByRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();
        boolean found = false;

        for (Message m : sentMessages) {
            if (m.recipient.equals(recipient)) {
                sb.append("\"").append(m.messageText).append("\" ");
                found = true;
            }
        }
        for (Message m : storedMessages) {
            if (m.recipient.equals(recipient)) {
                sb.append("\"").append(m.messageText).append("\" ");
                found = true;
            }
        }

        if (!found) {
            return "No messages found for recipient " + recipient;
        }
        return sb.toString().trim();
    }

    // -----------------------------------------------------------------------
    // 2e. Delete a message using the message hash. Removes the message from
    //     the storedMessages array, updates the JSON file, and returns a
    //     confirmation string.
    // -----------------------------------------------------------------------
    public static String deleteMessageByHash(String hash) {
        Iterator<Message> it = storedMessages.iterator();
        while (it.hasNext()) {
            Message m = it.next();
            if (m.messageHash.equals(hash)) {
                it.remove();
                saveStoredMessagesToFile();
                return "Message: \"" + m.messageText + "\" successfully deleted.";
            }
        }
        return "No stored message found with hash " + hash;
    }

    // -----------------------------------------------------------------------
    // 2f. Display a report that lists the full details of all the stored
    //     messages.
    // -----------------------------------------------------------------------
    public static String displayStoredReport() {
        if (storedMessages.isEmpty()) {
            return "No stored messages.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : storedMessages) {
            sb.append("Message ID: ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n");
            sb.append("-----------------------------\n");
        }
        return sb.toString();
    }

    // -----------------------------------------------------------------------
    // Combines the sent, disregarded and stored arrays into one list, used
    // for searching by message ID.
    // -----------------------------------------------------------------------
    private static ArrayList<Message> getAllMessages() {
        ArrayList<Message> all = new ArrayList<>();
        all.addAll(sentMessages);
        all.addAll(disregardedMessages);
        all.addAll(storedMessages);
        return all;
    }

    // -----------------------------------------------------------------------
    // setMessageID() — allows a custom message ID to be assigned (used for
    // populating test data). Recalculates the message hash to match, since
    // the hash depends on the first two digits of the ID.
    // -----------------------------------------------------------------------
    public void setMessageID(String newID) {
        messageIDs.remove(this.messageID);
        messageHashes.remove(this.messageHash);

        this.messageID = newID;
        this.messageHash = createMessageHash();

        messageIDs.add(this.messageID);
        messageHashes.add(this.messageHash);
    }

    // -----------------------------------------------------------------------
    // setSenderNumber() — sets the cell number of the QuickChat user (used
    // when displaying the sender of stored messages).
    // -----------------------------------------------------------------------
    public static void setSenderNumber(String number) {
        senderNumber = number;
    }

    // -----------------------------------------------------------------------
    // Getters for the Part 3 arrays
    // -----------------------------------------------------------------------
    public static ArrayList<Message> getSentMessages()        { return sentMessages; }
    public static ArrayList<Message> getDisregardedMessages() { return disregardedMessages; }
    public static ArrayList<Message> getStoredMessages()      { return storedMessages; }
    public static ArrayList<String>  getMessageHashes()       { return messageHashes; }
    public static ArrayList<String>  getMessageIDs()          { return messageIDs; }

    // -----------------------------------------------------------------------
    // Getters
    // -----------------------------------------------------------------------
    public String getMessageID()   { return messageID; }
    public int    getMessageNumber() { return messageNumber; }
    public String getRecipient()   { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
}