import org.junit.Test;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import java.util.ArrayList;
import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MessageTest {

    // -----------------------------------------------------------------------
    // Test Data — Task 1
    // -----------------------------------------------------------------------
    private Message message1; // Recipient: +27718693002 | "Hi Mike, can you join us for dinner tonight?"
    private Message message2; // Recipient: 08575975889 | "Hi Keegan, did you receive the payment?"

    @Before
    public void setUp() {
        message1 = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        message2 = new Message(1, "08575975889",  "Hi Keegan, did you receive the payment?");
    }

    // =======================================================================
    // 1. MESSAGE LENGTH — must NOT exceed 250 characters
    // =======================================================================

    @Test
    public void testMessageLength_Success() {
        // message1 is well under 250 chars
        assertEquals("Message ready to send.", message1.checkMessage());
    }

    @Test
    public void testMessageLength_Failure() {
        // Build a message that is exactly 260 characters (10 over the limit)
        String longText = "A".repeat(260);
        Message longMsg = new Message(0, "+27700000000", longText);
        String result = longMsg.checkMessage();
        assertTrue("Failure message should mention exceeds 250",
                result.contains("Message exceeds 250 characters by 10"));
    }

    // =======================================================================
    // 2. RECIPIENT NUMBER — correctly formatted
    // =======================================================================

    @Test
    public void testRecipientCell_Success() {
        // +27718693002 starts with '+' and is ≤ 10 chars (+2771869300 = 12 chars)
        // NOTE: The spec says ≤10 chars. +27718693002 is 12 chars.
        // We test the formatting rule (starts with '+') — the spec example passes
        // the international-code check but may fail the length check.
        // Here we test a number that satisfies both constraints.
        Message validMsg = new Message(0, "+277186930", "Test message");
        assertEquals("Cell phone number successfully captured.", validMsg.checkRecipientCell());
    }

    @Test
    public void testRecipientCell_Failure_NoInternationalCode() {
        // message2 has 08575975889 — does NOT start with '+'
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            message2.checkRecipientCell()
        );
    }

    @Test
    public void testRecipientCell_Failure_TooLong() {
        Message tooLong = new Message(0, "+27123456789012", "Test");
        String result = tooLong.checkRecipientCell();
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            result
        );
    }

    // =======================================================================
    // 3. MESSAGE HASH — correct format
    // Expected for message1 (messageNumber=0):
    //   first 2 of ID : 0 : HI + TONIGHT  →  XX:0:HITONIGHT
    // We can only verify the structure, not the exact ID digits (random).
    // =======================================================================

    @Test
    public void testMessageHash_Structure() {
        String hash = message1.getMessageHash();
        // Hash must be uppercase
        assertEquals("Hash should be uppercase", hash, hash.toUpperCase());
        // Hash must have exactly 2 colons
        long colonCount = hash.chars().filter(c -> c == ':').count();
        assertEquals("Hash should contain 2 colons", 2, colonCount);
    }

    @Test
    public void testMessageHash_EndsWithFirstAndLastWord() {
        // message1: "Hi Mike, can you join us for dinner tonight?"
        // first word = "HI", last word = "TONIGHT" (punctuation stripped)
        String hash = message1.getMessageHash();
        String suffix = hash.substring(hash.lastIndexOf(':') + 1);
        assertEquals("HITONIGHT", suffix);
    }

    // =======================================================================
    // 4. MESSAGE ID — must be ≤ 10 characters
    // =======================================================================

    @Test
    public void testMessageID_Valid() {
        assertTrue("Message ID should be ≤ 10 characters", message1.checkMessageID());
    }

    // =======================================================================
    // 5. SENT MESSAGE — send / disregard / store
    // =======================================================================

    @Test
    public void testSentMessage_Send() {
        Message m = new Message(0, "+277186930", "Hello there");
        assertEquals("Message successfully sent.", m.SentMessage(1));
    }

    @Test
    public void testSentMessage_Disregard() {
        Message m = new Message(0, "+277186930", "Hello there");
        assertEquals("Press 0 to delete the message.", m.SentMessage(2));
    }

    @Test
    public void testSentMessage_Store() {
        Message m = new Message(0, "+277186930", "Hello there");
        assertEquals("Message successfully stored.", m.SentMessage(3));
    }

    // =======================================================================
    // 6. TOTAL MESSAGES — returnTotalMessages increments on send only
    // =======================================================================

    @Test
    public void testReturnTotalMessages() {
        int before = Message.returnTotalMessages();
        Message m = new Message(before, "+277186930", "Count test");
        m.SentMessage(1); // send
        assertEquals(before + 1, Message.returnTotalMessages());
    }

    // =======================================================================
    // PART 3 — Store Data and Display Task Report
    //
    // Test data (from the brief):
    //   Message 1: +27834557896 | "Did you get the cake?"                    | Sent
    //   Message 2: +27838884567 | "Where are you? You are late! I have       | Stored
    //                              asked you to be on time."
    //   Message 3: +27834484567 | "Yohoooo, I am at your gate."               | Disregard
    //   Message 4: 0838884567   | "It is dinner time !"                       | Sent
    //   Message 5: +27838884567 | "Ok, I am leaving without you."             | Stored
    //
    // These tests run in name order (testPart3a -> testPart3f) because the
    // Sent / Disregarded / Stored arrays are static and shared across tests,
    // so later tests rely on the array population done in testPart3a.
    // =======================================================================

    private static Message testMsg1, testMsg2, testMsg3, testMsg4, testMsg5;

    // -----------------------------------------------------------------------
    // testPart3a — Sent Messages array correctly populated
    // Test Data: Developer entry for Test Data Messages 1-4
    // The system returns: "Did you get the cake?", "It is dinner time!"
    // -----------------------------------------------------------------------
    @Test
    public void testPart3a_SentMessagesArrayPopulated() {
        testMsg1 = new Message(0, "+27834557896", "Did you get the cake?");
        testMsg2 = new Message(1, "+27838884567", "Where are you? You are late! I have asked you to be on time.");
        testMsg3 = new Message(2, "+27834484567", "Yohoooo, I am at your gate.");
        testMsg4 = new Message(3, "0838884567",   "It is dinner time !");
        testMsg5 = new Message(4, "+27838884567", "Ok, I am leaving without you.");

        // Message 4's "Developer" field (0838884567) is used as its
        // message ID for the search test below.
        testMsg4.setMessageID("0838884567");

        testMsg1.SentMessage(1); // Sent
        testMsg2.SentMessage(3); // Stored
        testMsg3.SentMessage(2); // Disregard
        testMsg4.SentMessage(1); // Sent
        testMsg5.SentMessage(3); // Stored

        ArrayList<String> sentTexts = new ArrayList<>();
        for (Message m : Message.getSentMessages()) {
            sentTexts.add(m.getMessageText());
        }

        assertTrue("Sent Messages array should contain 'Did you get the cake?'",
                sentTexts.contains("Did you get the cake?"));
        assertTrue("Sent Messages array should contain 'It is dinner time !'",
                sentTexts.contains("It is dinner time !"));
    }

    // -----------------------------------------------------------------------
    // testPart3b — Display the longest stored message
    // Test Data: messages 1-4
    // The system returns: "Where are you? You are late! I have asked you
    //                       to be on time."
    // -----------------------------------------------------------------------
    @Test
    public void testPart3b_DisplayLongestStoredMessage() {
        assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            Message.displayLongestStoredMessage()
        );
    }

    // -----------------------------------------------------------------------
    // testPart3c — Search for messageID
    // Test Data: message 4 -> "0838884567"
    // The system returns: "It is dinner time !"
    // -----------------------------------------------------------------------
    @Test
    public void testPart3c_SearchByMessageID() {
        assertEquals("It is dinner time !", Message.searchMessageTextByID("0838884567"));
    }

    // -----------------------------------------------------------------------
    // testPart3d — Search all the messages sent or stored regarding a
    //              particular recipient
    // Test Data: +27838884567
    // The system returns: "Where are you? You are late! I have asked you
    //                       to be on time." "Ok, I am leaving without you."
    // -----------------------------------------------------------------------
    @Test
    public void testPart3d_SearchByRecipient() {
        String result = Message.searchByRecipient("+27838884567");

        assertTrue("Result should include message 2's text",
                result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue("Result should include message 5's text",
                result.contains("Ok, I am leaving without you."));
    }

    // -----------------------------------------------------------------------
    // testPart3e — Delete a message using a message hash
    // Test Data: Test Message 2
    // The system returns: Message: "Where are you? You are late! I have
    //                       asked you to be on time." successfully deleted.
    // -----------------------------------------------------------------------
    @Test
    public void testPart3e_DeleteMessageByHash() {
        String hashToDelete = testMsg2.getMessageHash();
        String result = Message.deleteMessageByHash(hashToDelete);

        assertEquals(
            "Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.",
            result
        );

        // Confirm message 2 is no longer in the storedMessages array
        assertFalse(Message.getStoredMessages().contains(testMsg2));
    }

    // -----------------------------------------------------------------------
    // testPart3f — Display Report
    // The system returns a report that shows all the sent messages,
    // including the Message Hash, Recipient and Message.
    // -----------------------------------------------------------------------
    @Test
    public void testPart3f_DisplayReport() {
        String report = Message.printMessages();

        assertTrue(report.contains("Message Hash:"));
        assertTrue(report.contains("Recipient:"));
        assertTrue(report.contains("Message:"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("It is dinner time !"));
    }
}