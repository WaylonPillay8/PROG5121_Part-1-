/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.messagingapp;

/**
 *
 * @author Huawei
 */
public class MessagingApp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
