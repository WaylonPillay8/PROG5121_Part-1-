import java.util.Scanner;

public class Registration {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Welcome to the Messaging App ===");
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter Username: ");
        String username = scanner.nextLine();

        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        System.out.print("Enter Cell Phone Number (e.g. +27838968976): ");
        String cellPhone = scanner.nextLine();

        // Create user and register
        User user = new User(firstName, lastName, username, password, cellPhone);
        System.out.println("\n" + user.registerUser());

        // Login
        System.out.println("\n=== Login ===");
        System.out.print("Enter Username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter Password: ");
        String loginPassword = scanner.nextLine();

        System.out.println("\n" + user.returnLoginStatus(loginUsername, loginPassword));

        scanner.close();
    }
}