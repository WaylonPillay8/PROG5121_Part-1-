import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

public class MessageTest {

    // -----------------------------------------------------------------------
    // Test Data — Task 1
    // -----------------------------------------------------------------------
    private Message message1; // Recipient: +27718693002 | "Hi Mike, can you join us for dinner tonight?"
    private Message message2; // Recipient: 08575975889 | "Hi Keegan, did you receive the payment?"

    @Before
    public void setUp() {
        message1 = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        message2 = new Message(1, "08575975889",  "Hi Keegan, did you receive the payment?");
    }

    // =======================================================================
    // 1. MESSAGE LENGTH — must NOT exceed 250 characters
    // =======================================================================

    @Test
    public void testMessageLength_Success() {
        // message1 is well under 250 chars
        assertEquals("Message ready to send.", message1.checkMessage());
    }

    @Test
    public void testMessageLength_Failure() {
        // Build a message that is exactly 260 characters (10 over the limit)
        String longText = "A".repeat(260);
        Message longMsg = new Message(0, "+27700000000", longText);
        String result = longMsg.checkMessage();
        assertTrue("Failure message should mention exceeds 250",
                result.contains("Message exceeds 250 characters by 10"));
    }

    // =======================================================================
    // 2. RECIPIENT NUMBER — correctly formatted
    // =======================================================================

    @Test
    public void testRecipientCell_Success() {
        // +27718693002 starts with '+' and is ≤ 10 chars (+2771869300 = 12 chars)
        // NOTE: The spec says ≤10 chars. +27718693002 is 12 chars.
        // We test the formatting rule (starts with '+') — the spec example passes
        // the international-code check but may fail the length check.
        // Here we test a number that satisfies both constraints.
        Message validMsg = new Message(0, "+277186930", "Test message");
        assertEquals("Cell phone number successfully captured.", validMsg.checkRecipientCell());
    }

    @Test
    public void testRecipientCell_Failure_NoInternationalCode() {
        // message2 has 08575975889 — does NOT start with '+'
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            message2.checkRecipientCell()
        );
    }

    @Test
    public void testRecipientCell_Failure_TooLong() {
        Message tooLong = new Message(0, "+27123456789012", "Test");
        String result = tooLong.checkRecipientCell();
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            result
        );
    }

    // =======================================================================
    // 3. MESSAGE HASH — correct format
    // Expected for message1 (messageNumber=0):
    //   first 2 of ID : 0 : HI + TONIGHT  →  XX:0:HITONIGHT
    // We can only verify the structure, not the exact ID digits (random).
    // =======================================================================

    @Test
    public void testMessageHash_Structure() {
        String hash = message1.getMessageHash();
        // Hash must be uppercase
        assertEquals("Hash should be uppercase", hash, hash.toUpperCase());
        // Hash must have exactly 2 colons
        long colonCount = hash.chars().filter(c -> c == ':').count();
        assertEquals("Hash should contain 2 colons", 2, colonCount);
    }

    @Test
    public void testMessageHash_EndsWithFirstAndLastWord() {
        // message1: "Hi Mike, can you join us for dinner tonight?"
        // first word = "HI", last word = "TONIGHT" (punctuation stripped)
        String hash = message1.getMessageHash();
        String suffix = hash.substring(hash.lastIndexOf(':') + 1);
        assertEquals("HITONIGHT", suffix);
    }

    // =======================================================================
    // 4. MESSAGE ID — must be ≤ 10 characters
    // =======================================================================

    @Test
    public void testMessageID_Valid() {
        assertTrue("Message ID should be ≤ 10 characters", message1.checkMessageID());
    }

    // =======================================================================
    // 5. SENT MESSAGE — send / disregard / store
    // =======================================================================

    @Test
    public void testSentMessage_Send() {
        Message m = new Message(0, "+277186930", "Hello there");
        assertEquals("Message successfully sent.", m.SentMessage(1));
    }

    @Test
    public void testSentMessage_Disregard() {
        Message m = new Message(0, "+277186930", "Hello there");
        assertEquals("Press 0 to delete the message.", m.SentMessage(2));
    }

    @Test
    public void testSentMessage_Store() {
        Message m = new Message(0, "+277186930", "Hello there");
        assertEquals("Message successfully stored.", m.SentMessage(3));
    }

    // =======================================================================
    // 6. TOTAL MESSAGES — returnTotalMessages increments on send only
    // =======================================================================

    @Test
    public void testReturnTotalMessages() {
        int before = Message.returnTotalMessages();
        Message m = new Message(before, "+277186930", "Count test");
        m.SentMessage(1); // send
        assertEquals(before + 1, Message.returnTotalMessages());
    }
}