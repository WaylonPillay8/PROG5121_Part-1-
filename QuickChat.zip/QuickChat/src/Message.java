import java.util.ArrayList;
import java.util.Random;

public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;

    // Static list to track all sent messages during the session
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static int totalMessageCount = 0;

    // Constructor
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    // Generates a random 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        long id = (long) (rand.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    // -----------------------------------------------------------------------
    // Boolean: checkMessageID()
    // Ensures the message ID is not more than 10 characters
    // -----------------------------------------------------------------------
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // -----------------------------------------------------------------------
    // String: checkRecipientCell()
    // Ensures the recipient cell number is no more than 10 characters long
    // and starts with an international code (i.e. starts with '+')
    // -----------------------------------------------------------------------
    public String checkRecipientCell() {
        if (recipient.length() <= 10 && recipient.startsWith("+")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // -----------------------------------------------------------------------
    // String: checkMessage()
    // Validates message length (max 250 characters)
    // -----------------------------------------------------------------------
    public String checkMessage() {
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }

    // -----------------------------------------------------------------------
    // String: createMessageHash()
    // Format: first 2 digits of messageID + ":" + messageNumber + ":" +
    //         first word of message + last word of message — all in CAPS
    // Example: 00:0:HITONIGHT
    // -----------------------------------------------------------------------
    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);

        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        // Strip trailing punctuation from last word
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");

        String hash = firstTwo + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    // -----------------------------------------------------------------------
    // String: SentMessage()
    // Prompts user to send, store, or disregard the message.
    // Returns the appropriate confirmation string.
    // -----------------------------------------------------------------------
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                sentMessages.add(this);
                totalMessageCount++;
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                return "Message successfully stored.";
            default:
                return "Invalid option selected.";
        }
    }

    // -----------------------------------------------------------------------
    // String: printMessages()
    // Returns all messages sent while the program is running
    // -----------------------------------------------------------------------
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient: ").append(m.recipient).append("\n");
            sb.append("Message: ").append(m.messageText).append("\n");
            sb.append("-----------------------------\n");
        }
        return sb.toString();
    }

    // -----------------------------------------------------------------------
    // Int: returnTotalMessages()
    // Returns the total number of messages sent
    // -----------------------------------------------------------------------
    public static int returnTotalMessages() {
        return totalMessageCount;
    }

    // -----------------------------------------------------------------------
    // storeMessage() — stores the message as a JSON entry in a file
    // -----------------------------------------------------------------------
    public void storeMessage() {
        try {
            java.io.FileWriter fw = new java.io.FileWriter("stored_messages.json", true);
            fw.write("{\n");
            fw.write("  \"messageID\": \"" + messageID + "\",\n");
            fw.write("  \"messageNumber\": " + messageNumber + ",\n");
            fw.write("  \"recipient\": \"" + recipient + "\",\n");
            fw.write("  \"message\": \"" + messageText + "\",\n");
            fw.write("  \"messageHash\": \"" + messageHash + "\"\n");
            fw.write("}\n");
            fw.close();
        } catch (java.io.IOException e) {
            System.out.println("Error storing message: " + e.getMessage());
        }
    }

    // -----------------------------------------------------------------------
    // Getters
    // -----------------------------------------------------------------------
    public String getMessageID()   { return messageID; }
    public int    getMessageNumber() { return messageNumber; }
    public String getRecipient()   { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
}