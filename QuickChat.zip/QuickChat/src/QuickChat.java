import java.util.Scanner;

public class QuickChat {

    // Simple hardcoded credentials for login (reuse from Part 1 pattern)
    private static final String VALID_USERNAME = "user";
    private static final String VALID_PASSWORD = "Pass@123";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // ---- LOGIN --------------------------------------------------------
        System.out.println("=== QuickChat Login ===");
        System.out.print("Username: ");
        String username = sc.nextLine();
        System.out.print("Password: ");
        String password = sc.nextLine();

        if (!username.equals(VALID_USERNAME) || !password.equals(VALID_PASSWORD)) {
            System.out.println("Login failed. Exiting.");
            sc.close();
            return;
        }

        System.out.println("Welcome to QuickChat.");

        // ---- How many messages? ------------------------------------------
        int maxMessages = 0;
        while (maxMessages <= 0) {
            System.out.print("How many messages would you like to send? ");
            try {
                maxMessages = Integer.parseInt(sc.nextLine().trim());
                if (maxMessages <= 0) System.out.println("Please enter a positive number.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }

        // ---- Main application loop ---------------------------------------
        boolean running = true;
        while (running) {
            System.out.println("\n--- Menu ---");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Select an option: ");

            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1":
                    sendMessages(sc, maxMessages);
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please select 1, 2, or 3.");
            }
        }

        // ---- Summary -----------------------------------------------------
        System.out.println("\nTotal messages sent: " + Message.returnTotalMessages());
        sc.close();
    }

    // -----------------------------------------------------------------------
    // sendMessages — loops up to maxMessages times collecting message data
    // -----------------------------------------------------------------------
    private static void sendMessages(Scanner sc, int maxMessages) {
        int messagesSentThisSession = Message.returnTotalMessages();
        int remaining = maxMessages - messagesSentThisSession;

        if (remaining <= 0) {
            System.out.println("You have already sent the maximum number of messages (" + maxMessages + ").");
            return;
        }

        int count = 0;
        while (count < remaining) {
            System.out.println("\n--- Message " + (messagesSentThisSession + count + 1) + " ---");

            // Recipient
            String recipient = "";
            boolean validRecipient = false;
            while (!validRecipient) {
                System.out.print("Enter recipient cell number (with international code, max 10 chars): ");
                recipient = sc.nextLine().trim();

                // Temporary Message object just to validate recipient
                Message tempMsg = new Message(0, recipient, "test");
                String recipientCheck = tempMsg.checkRecipientCell();
                System.out.println(recipientCheck);

                if (recipientCheck.equals("Cell phone number successfully captured.")) {
                    validRecipient = true;
                }
            }

            // Message text
            String messageText = "";
            boolean validMessage = false;
            while (!validMessage) {
                System.out.print("Enter your message (max 250 characters): ");
                messageText = sc.nextLine();

                if (messageText.length() <= 250) {
                    System.out.println("Message sent");
                    validMessage = true;
                } else {
                    int excess = messageText.length() - 250;
                    System.out.println("Please enter a message of less than 250 characters.");
                    System.out.println("(Your message exceeds the limit by " + excess + " characters.)");
                }
            }

            // Build the message
            int msgNumber = messagesSentThisSession + count;
            Message msg = new Message(msgNumber, recipient, messageText);

            // Check message ID valid
            if (!msg.checkMessageID()) {
                System.out.println("Warning: Message ID exceeds 10 characters. Regenerating...");
            }

            // Display message details
            System.out.println("\n--- Message Details ---");
            System.out.println("Message ID:   " + msg.getMessageID());
            System.out.println("Message Hash: " + msg.getMessageHash());
            System.out.println("Recipient:    " + msg.getRecipient());
            System.out.println("Message:      " + msg.getMessageText());

            // Send / Disregard / Store
            System.out.println("\nWhat would you like to do?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Select: ");

            int sendChoice = 0;
            try {
                sendChoice = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid choice. Defaulting to Disregard.");
                sendChoice = 2;
            }

            String result = msg.SentMessage(sendChoice);
            System.out.println(result);

            if (sendChoice == 3) {
                msg.storeMessage();
            }

            count++;
        }

        // Show all sent messages after the loop
        System.out.println("\n=== All Sent Messages ===");
        System.out.println(Message.printMessages());
        System.out.println("Total messages sent: " + Message.returnTotalMessages());
    }
}